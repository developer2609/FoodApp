package com.example.a12myhomework2

data class Malumot(
    var text:String,
    var info:String
)
